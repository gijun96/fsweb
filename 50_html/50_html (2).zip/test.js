const  carousel = document.querySelector('.carousel');
const prevBtn = document.querySelector('.prevBtn');
const nextBtn = document.querySelector('.nextBtn');

let index = 0;

nextBtn.addEventListener('click', ()=>{
    if(index === 2){
        index = 0;
    }else{

        index+= 1;
    }
    carousel.style.transform = `translate3d(${index} *500px, 0, 0)`;
})