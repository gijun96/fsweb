package A1004;

import java.util.Scanner;

public class A1004_test34 {
    public static void main(String[] args) {

     Scanner scanner =new Scanner(System.in);
     while(true) {
         int num = scanner.nextInt();
         System.out.println(num);
         if(num ==0)break;
     }
    }
}
