package A1004;

import java.util.Scanner;

public class A1004_test36 {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        int n_val = scanner.nextInt();
        int m_val = scanner.nextInt();

    for(int n =1; n<=n_val;n++){
        for (int m =1; m <=m_val; m++){
            System.out.println(n +" , "+m);
        }
    }


    }
}
