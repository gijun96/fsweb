package exam;

import java.util.Scanner;

public class exam_44 {
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int sc = scanner.nextInt();
    if (sc%2 ==0){
        System.out.println("enjoy");
    }else{
        System.out.println("oh my god");
    }
        }

    }

